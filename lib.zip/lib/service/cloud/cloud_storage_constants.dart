const ownerUserIDFieldName = 'user_id';
const textFieldName = 'text';